package com.wmt.hmwork.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.wmt.hmwork.bo.SeatHold;
import com.wmt.hmwork.bo.Venue;
import com.wmt.hmwork.service.impl.TicketServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class) 
@ContextConfiguration(loader=AnnotationConfigContextLoader.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TicketServiceTest {
	  @Configuration
	    static class ContextConfiguration {

	        @Bean
	        public TicketService ticketService() {
	        	TicketService ticketService = new TicketServiceImpl();
	            // set properties, etc.
	            return ticketService;
	        }
	    }
	  
	
	@Autowired
	private TicketService ticketService;
	private String email;

	@Before
	public void init() {
		email = "abc@abc.com";
	}

	@Test
	public void getNumberOfSeatsAvailable() {
		assertEquals(1250, ticketService.numSeatsAvailable(Venue.enumOf(1)));
		assertEquals(2000, ticketService.numSeatsAvailable(Venue.enumOf(2)));
		assertEquals(1500, ticketService.numSeatsAvailable(Venue.enumOf(3)));
		assertEquals(1500, ticketService.numSeatsAvailable(Venue.enumOf(4)));
	}
	
	
	@Test
	public void seatsAvailableInMinLevel_BooksMinLevel() {
		int minLevel = 2, maxLevel = 3;
		SeatHold seatHoldInfo = ticketService.findAndHoldSeats(5, Venue.enumOf(minLevel),Venue.enumOf(maxLevel), email);
		assertEquals(minLevel, seatHoldInfo.getVenue().getLevel());
	}
	
	
	@Test
	public void seatsRequiredNotAvailableInMinLevel_BooksFromNextLevel() {
		int minLevel = 2, maxLevel = 4;
		SeatHold seatHoldInfo = ticketService.findAndHoldSeats(1600, Venue.enumOf(minLevel), Venue.enumOf(maxLevel), email);
		ticketService.reserveSeats(seatHoldInfo.getSeatHoldId(), email);
		assertEquals(2, seatHoldInfo.getVenue().getLevel());
	}
	
	
	@Test
	public void invalidateHoldSeats() {
		String expectedOutput = "";
		SeatHold seatHoldInfo = ticketService.findAndHoldSeats(10,Venue.enumOf(4), Venue.enumOf(3), email);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String code = ticketService.reserveSeats(seatHoldInfo.getSeatHoldId(), email);
		assertEquals(expectedOutput, code);
	}


}
