package com.wmt.hmwork.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.wmt.hmwork.bo.Seat;
import com.wmt.hmwork.bo.SeatHold;
import com.wmt.hmwork.bo.Venue;
import com.wmt.hmwork.service.TicketService;

/**
 * 
 * @author anilchinnam
 *
 */

@Service(value="TicketService")
public class TicketServiceImpl implements TicketService {

	private static final Logger logger = LoggerFactory.getLogger(TicketServiceImpl.class);
	
	private static Map<Integer, SeatHold> onHoldSeats = new ConcurrentHashMap<Integer, SeatHold>();
	private static Map<String, List<Seat>> reservedSeats = new ConcurrentHashMap<String, List<Seat>>();
	private static Map<Venue, List<Seat>> availableSeats = new ConcurrentHashMap<Venue, List<Seat>>();
	private static AtomicInteger seatHoldReservationId = new AtomicInteger(1);
	//set time in seconds-15
	private static final long SEAT_HOLD_INTERVAL = 15000;
	private static List<Venue> sortedVenueList = Arrays.asList(Venue.values());
	
	/**
	 * This method will be called after the TicketService bean is constructed 
	 * but before it is being initialized.This method initializes the list of available seats
	 * at each Venue based on the seats defined.
	 */
	@PostConstruct
	private void init(){
		for (Venue level : Venue.values()) {
			for (int i = 1; i <= level.getNumOfRows(); i++) {
				for (int j = 1; j <= level.getNumOfSeats(); j++) {
					if (availableSeats.get(level) == null) {
						availableSeats.put(level, new ArrayList<Seat>());
					}
					availableSeats.get(level).add(new Seat(j, i));
				}
			}
		}
		
		Collections.sort(sortedVenueList, new Comparator<Venue>() {
			@Override
			public int compare(Venue venue1, Venue venue2) {
				return venue1.getLevel() - venue2.getLevel();
			}
		});
	}
	
	/**
	 * This method reclaims the seats that are held more than
	 * the required time limit
	 */
	private void refreshHoldSeatStatus(){
		logger.debug("\n refreshHoldSeatStatus");
		//Get all the onHoldSeats
		Iterator<Entry<Integer, SeatHold>> iterator = onHoldSeats.entrySet().iterator();
		Date date = new Date();

		while (iterator.hasNext()) {
			Entry<Integer, SeatHold> entry = iterator.next();
			SeatHold seatHoldInfo = entry.getValue();
			long holdTimeElapsed=date.getTime() - seatHoldInfo.getHoldTime().getTime();
			logger.debug("holdTimeElapsed:"+holdTimeElapsed+" SEAT_HOLD_INTERVAL"+SEAT_HOLD_INTERVAL);
			//reclaim the held seats if the seat hold interval is passed
			if (holdTimeElapsed > SEAT_HOLD_INTERVAL) {
				availableSeats.get(seatHoldInfo.getVenue()).addAll(seatHoldInfo.getSeats());
				iterator.remove();
			}
		}
	}
	
	@Override
	public int numSeatsAvailable(Venue venueLevel) {
		refreshHoldSeatStatus();
		logger.debug("numSeatsAvailable:{}"+venueLevel);
		return availableSeats.get(venueLevel).size();
	}

	@Override
	public SeatHold findAndHoldSeats(int numSeats, Venue minLevel,
			Venue maxLevel, String customerEmail) {
		refreshHoldSeatStatus();
		SeatHold seatHoldInfo = new SeatHold(seatHoldReservationId.getAndIncrement());

	 for (Venue venue : sortedVenueList) {
			if (venue.getLevel() >= minLevel.getLevel() 
					&& venue.getLevel() <= maxLevel.getLevel()) {
				if (availableSeats.get(venue).size() >= numSeats) {
					List<Seat> seats = new ArrayList<Seat>(availableSeats.get(venue).subList(0, numSeats));
					availableSeats.get(venue).subList(0, numSeats).clear();
					seatHoldInfo.setSeats(seats);
					seatHoldInfo.setHoldTime(new Date());
					seatHoldInfo.setVenue(venue);
					onHoldSeats.put(seatHoldInfo.getSeatHoldId(), seatHoldInfo);
					break;
				}
			}
		}

		return seatHoldInfo;
	
	}

	@Override
	public String reserveSeats(int seatHoldId, String customerEmail) {
		String confirmationCode = "";
		refreshHoldSeatStatus();
		SeatHold seatHoldInfo = onHoldSeats.get(seatHoldId);
		//reserve seats only if the seats are held
		if (seatHoldInfo != null) {
			List<Seat> seats = seatHoldInfo.getSeats();
			confirmationCode = UUID.randomUUID().toString();
			reservedSeats.put(customerEmail + confirmationCode, seats);
			onHoldSeats.remove(seatHoldId);
		}

		return confirmationCode;
	}

}
