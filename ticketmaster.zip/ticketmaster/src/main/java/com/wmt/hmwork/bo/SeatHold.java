package com.wmt.hmwork.bo;

import java.util.Date;
import java.util.List;

/**
 * 
 * @author anilchinnam
 *
 */
public class SeatHold {
	
	private List<Seat> seats;
	private Date holdTime;
	private Venue venue;
	private int seatHoldId;
	
	
	public SeatHold(int seatHoldId) {
		super();
		this.seatHoldId = seatHoldId;
	}
	/**
	 * @return the seats
	 */
	public List<Seat> getSeats() {
		return seats;
	}
	/**
	 * @param seats the seats to set
	 */
	public void setSeats(List<Seat> seats) {
		this.seats = seats;
	}
	/**
	 * @return the holdTime
	 */
	public Date getHoldTime() {
		return holdTime;
	}
	/**
	 * @param holdTime the holdTime to set
	 */
	public void setHoldTime(Date holdTime) {
		this.holdTime = holdTime;
	}
	/**
	 * @return the Venue
	 */
	public Venue getVenue() {
		return venue;
	}
	/**
	 * @param level the level to set
	 */
	public void setVenue(Venue venue) {
		this.venue = venue;
	}
	/**
	 * @return the seatHoldId
	 */
	public int getSeatHoldId() {
		return seatHoldId;
	}
	/**
	 * 
	 * @param seatHoldId
	 */
	public void setSeatHoldId(int seatHoldId) {
		this.seatHoldId = seatHoldId;
	}



}
