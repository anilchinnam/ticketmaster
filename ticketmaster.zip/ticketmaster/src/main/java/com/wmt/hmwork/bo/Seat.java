package com.wmt.hmwork.bo;

/**
 * 
 * @author anilchinnam
 *
 */
public class Seat {

	private int seatNumber;
	private int rowNumber;
   
	/**
	 * Constructor method
	 * @param seatNumber
	 * @param rowNumber
	 */
	public Seat(int seatNumber, int rowNumber) {
		this.seatNumber = seatNumber;
		this.rowNumber = rowNumber;
	}

	/**
	 * 
	 * @return
	 */
	public int getSeatNumber() {
		return seatNumber;
	}

	/**
	 * 
	 * @param seatNumber
	 */
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	/**
	 * 
	 * @return
	 */
	public int getRowNumber() {
		return rowNumber;
	}

	/**
	 * 
	 * @param rowNumber
	 */
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
}