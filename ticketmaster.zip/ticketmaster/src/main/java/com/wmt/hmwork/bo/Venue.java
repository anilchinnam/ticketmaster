package com.wmt.hmwork.bo;


/**
 * 
 * @author anilchinnam
 *
 */
public enum Venue {

	ORCHESTRA(1,"Orchestra", 100.00, 25, 50), 
	MAIN(2,"Main", 75.00, 20, 100), 
	BALCONY2(3,"Balcony2", 50.00, 15, 100), 
	BALCONY1(4,"Balcony1", 40.00, 15, 100);

	private int level;
	private String name;
	private double price;
	private int numOfRows;
	private int numOfSeats;
	
	/**
	 * Constructor for Venue
	 * @param level
	 * @param name
	 * @param price
	 * @param numOfRows
	 * @param numOfSeats
	 */
	 Venue(int level, String name, double price, int numOfRows,
			int numOfSeats) {
		this.level = level;
		this.name = name;
		this.price = price;
		this.numOfRows = numOfRows;
		this.numOfSeats = numOfSeats;
	}
	 
	/**
	 * This method returns the Venue enum for the given level id 
	 * @param level
	 * @return
	 */
	public static Venue enumOf(final int level) {
		for (Venue venue : values()) {
			if (venue.getLevel()==level) {
				return venue;
			}
		}
		throw new IllegalArgumentException("Unknown enum code [" + level + "]");
	}

	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the numOfRows
	 */
	public int getNumOfRows() {
		return numOfRows;
	}

	/**
	 * @param numOfRows the numOfRows to set
	 */
	public void setNumOfRows(int numOfRows) {
		this.numOfRows = numOfRows;
	}

	/**
	 * @return the numOfSeats
	 */
	public int getNumOfSeats() {
		return numOfSeats;
	}

	/**
	 * @param numOfSeats the numOfSeats to set
	 */
	public void setNumOfSeats(int numOfSeats) {
		this.numOfSeats = numOfSeats;
	}
	
	
	
	
}
