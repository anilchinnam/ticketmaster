package com.wmt.hmwork.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.wmt.hmwork.bo.SeatHold;
import com.wmt.hmwork.bo.Venue;
import com.wmt.hmwork.service.TicketService;

/**
 * 
 * @author anilchinnam
 *
 */

@RestController
public class TicketController {
	
	private static final Logger logger = LoggerFactory.getLogger(TicketController.class);
	 @Autowired
	 private TicketService tktService; 
	
     @RequestMapping(value = "/hello", method = RequestMethod.GET)
     public @ResponseBody int getAvailableSeatsBylev() {
         return 10;
     }  
     
     @RequestMapping(value = "/seats/{level}", method = RequestMethod.GET)
     public ResponseEntity<Integer> getAvailableSeatsByVenue(@PathVariable("level") int venueLevel) throws Exception {
    	 logger.debug("Inside getAvailableSeatsByVenue method, Venue Level {}"+ venueLevel);
		return new ResponseEntity<Integer>(Integer.valueOf(tktService
				.numSeatsAvailable(Venue.enumOf(venueLevel))), HttpStatus.OK);
     }
     
     @RequestMapping(value = "/seats/hold", method = RequestMethod.GET)
     public ResponseEntity<SeatHold> findAndHoldSeats(@RequestParam("numOfSeats") int numOfSeats,
    		 @RequestParam("minLevel") int minLevel,
    		 @RequestParam("maxLevel") int maxLevel,
    		 @RequestParam("customerEmail") String customerEmail) throws Exception {
    	 logger.debug("Inside findAndHoldSeats method, Venue Level {}"+ numOfSeats +"min:"+minLevel
    			 +"Max:"+maxLevel+"customerEmail:"+customerEmail);
		return new ResponseEntity<SeatHold>(tktService.findAndHoldSeats(numOfSeats, Venue.enumOf(minLevel), Venue.enumOf(maxLevel), customerEmail), HttpStatus.OK);
     }
  
     @RequestMapping(value = "/seats/reserve", method = RequestMethod.GET)
     public ResponseEntity<String> reserveSeats(@RequestParam("seatHoldId") int seatHoldId,
    		 @RequestParam("customerEmail") String customerEmail){
    	 logger.debug("Inside reserveSeats method, seatHoldId:"+ seatHoldId +"customerEmail:"+customerEmail);
    	 return new ResponseEntity<String>(tktService.reserveSeats(seatHoldId, customerEmail), HttpStatus.OK);
     }
 
}
